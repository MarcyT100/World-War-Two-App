 [
  {
  "firstName" : "Juan",
  "lastName" : "Pujol",
  "birthDate" : "February 14, 1912",
  "deathDate" : "October 10, 1988",
  "affiliation" : "MI5",
  "bio" : "Alias Garbo (MI5), Aracel (Abewhr).\nPujol, determined to due his part to help the world, approached the British to be a spy. After being rejected multiple times, he went to work for the Germans in order to have information to get the British's attention. After nine months of pretending to work for the British, the British intercepted his messages and recruited him for the Double Cross. He went on to play a major role in a number of MI5 opperations, most notably Operation Fortitude.",
  "picture" : "juanPujol"
  },
  {
  "firstName" : "Tommy",
  "lastName" : "Harris",
  "birthDate" : "April 10, 1908",
  "deathDate" : "January 27, 1964",
  "affiliation" : "MI5",
  "bio" : "Harris was Juan Pujol's MI5 case officer, helping Pujol create his vast array of fictional agents.",
  "picture" : "tommyHarris"
  },
  {
  "firstName" : "Thomas Argyll \"TAR\"",
  "lastName" : "Robertson",
  "birthDate" : "October 27, 1909",
  "deathDate" : "May 10, 1994",
  "affiliation" : "MI5",
  "bio" : "Robertson was in charge of the Double Cross, a campaign that captured every German agent sent to Britian during the war, with the exception of one who committed suicide. The Double Cross then turned a team of double agents and fed the Abewhr a complex web of disinformation.",
  "picture" : "tarRobertson"
  },
  {
  "firstName" : "John",
  "lastName" : "Masterman",
  "birthDate" : "January 12, 1891",
  "deathDate" : "June 6, 1977",
  "affiliation" : "MI5",
  "bio" : "A history professor at Oxford, Masterman was recruited to chair the Double Cross committee. He went on to write a book on the organization after the war.",
  "picture" : "johnMasterman"
  },
  {
  "firstName" : "Paul",
  "lastName" : "Fidrmuc",
  "birthDate" : "June 28, 1898",
  "deathDate" : "October 20, 1958",
  "affiliation" : "Abewhr",
  "bio" : "Fidrmuc, alias Agent Ostro, supplied Abewhr with intelligance about Britain, including that the invassion would take place at Normandy. However, everything he told the Germans was conjecture and guesswork, since he was not even in Britain. He and Agent Garbo inspired Graham Greene's spy novel 'Our Man in Havana'",
  "picture" : "paulFidrmuc"
  },
  {
  "firstName" : "Hans",
  "lastName" : "Oster",
  "birthDate" : "August 9, 1887",
  "deathDate" : "April 9, 1945",
  "affiliation" : "Abewhr",
  "bio" : "Oster was Admiral Canaris's deputy. He was vehemently anti-nazi and helped Jews escape arrest. After the failed July 20th bomb plot, he was arrested and ultimately executed at Flossenberg concentration camp.",
  "picture" : "hansOster"
  },
  {
  "firstName" : "Wilhelm",
  "lastName" : "Canaris",
  "birthDate" : "January 1, 1887",
  "deathDate" : "April 9, 1945",
  "affiliation" : "Abewhr",
  "bio" : "Canaris was the head of the Abewhr. He opposed the Nazis and was executed at Flossenberg concentration camp.",
  "picture" : "wilhelmCanaris"
  },
  {
  "firstName" : "Roger",
  "lastName" : "Michael",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "Abewhr",
  "bio" : "Michael was Hans Oster's assistant and may have been spying for the Soviet Union. At the end of the war, he vanished.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Dusko",
  "lastName" : "Popov",
  "birthDate" : "July 10, 1912",
  "deathDate" : "August 10, 1981",
  "affiliation" : "MI5",
  "bio" : "Alias: Agent Tricycle (MI5), Agent Ivan (Abewhr)\nPopov was recruited to the Abewhr by his longtime friend Johnny Jebsen and quickly defected to MI5, becoming one of their star double agents. He was the inspiration for Ian Fleming's James Bond.",
  "picture" : "duskoPopov"
  },
  {
  "firstName" : "Johnny",
  "lastName" : "Jebsen",
  "birthDate" : "1917",
  "deathDate" : "1945",
  "affiliation" : "Abewhr/MI5/MI6",
  "bio" : "Alias: Agent Artist (MI5)\nAnti-nazi and an anglophile from his college years, Jebsen joined the Abewhr to avoid military service and recruited his friend Dusko Popov. He later began informing to MI6, becoming friends with MI6 agent Charles de Salis. Under suspicion for dubious finacial dealings, he was kidnapped by the Abewhr and held in Sachsenhausen concentration camp. He is persumed to have died near the end of the war.",
  "picture" : "johnnyJebsen"
  },
  {
  "firstName" : "Ludovico",
  "lastName" : "von Karsthoff",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "",
  "bio" : "Von Karsthoff was the head of the Abewhr station in Lisbon and ran agent Dusko Popov with Johnny Jebsen. He is believed to have been captured by the Soviets and killed at the end of the war.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Billy",
  "lastName" : "Luke",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Luke was one of Dusko Popov's MI5 case officers and kept an eye on the fun-loving double agent.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Ian",
  "lastName" : "Wilson",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Ian Wilson was Dusko Popov's and Johnny Jebsen's MI5 case officer.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Lily",
  "lastName" : "Sergeyev",
  "birthDate" : "1912",
  "deathDate" : "1950",
  "affiliation" : "MI5",
  "bio" : "Alias: Treasure (MI5), Tramp (Abewhr)\n Sergeyev was recruited by Emile Kliemann for the Abwehr and was ultimately recruited as a double agent for MI5. Relations between Sergeyev and MI5, especially her case officer Mary Sherer, were always strained and disintegrated after the death of her beloved dog Babs, which she blamed MI5 for.",
  "picture" : "lilySergeyev"
  },
  {
  "firstName" : "Eddie",
  "lastName" : "Chapman",
  "birthDate" : "November 16, 1914",
  "deathDate" : "December 11, 1997",
  "affiliation" : "MI5",
  "bio" : "Alias: Zigzag (MI5), Fritz (Abewhr)\nChapman was a safecracker prior to the war. He was in jail on the Island of Jersey when the Germans took it over and was recruited by Abewhr as a spy. After spending months in training, he was dropped in Britain, where he imeadietly defected. He worked for MI5, faking sabotage, including the impressive faked sabotage of the De Haviland airplane factory, before returning to occupied Europe for a hero's welcome. He was dropped in Britain again, near the end of the war, where he stayed.",
  "picture" : "eddieChapman"
  },
  {
  "firstName" : "Roman",
  "lastName" : "Czerniawski",
  "birthDate" : "February 6, 1910",
  "deathDate" : "April 26, 1985",
  "affiliation" : "Interallie/MI5",
  "bio" : "Alias: Brutus (MI5), Hubert (Abewhr)\nAfter the fall of Poland, Polish intelligance officer Czerniawski formed the Interallie, an allied intelligance network in France, with Mathilde Carre. After Carre's betrayal, he, along with other agents, were arrested, and he was offered a deal to save the others by going to Britain as a spy. He did so and was ultimately recruited by the Double Cross. His primary goal during the war was to free Poland. After the war, unable to go back to a Poland controlled by the Soviet Union, settled in Britain.",
  "picture" : "romanCzerniawski"
  },
  {
  "firstName" : "Christopher",
  "lastName" : "Harmer",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Harmer was Roman Czerniawski's and Elvia de la Fuente Chaudoir's MI5 case officer.",
  "picture" : "christopherHarmer"
  },
  {
  "firstName" : "Hugh",
  "lastName" : "Astor",
  "birthDate" : "November 20, 1920",
  "deathDate" : "June 7, 1999",
  "affiliation" : "MI5",
  "bio" : "Astor was Roman Czerniawski's and Elvia de la Fuente Chaudoir's MI5 case officer.",
  "picture" : "hughAstor"
  },
  {
  "firstName" : "Oscar",
  "lastName" : "Reile",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "Abewhr",
  "bio" : "Reile was Roman Czerniawski's Abewhr case officer.",
  "picture" : "oscarReile"
  },
  {
  "firstName" : "Mary",
  "lastName" : "Sherer",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Sherer was Lily Sergeyev's MI5 case officer.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Emile",
  "lastName" : "Kliemann",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "Abewhr",
  "bio" : "Kliemann was Lily Sergeyev's Abewhr case officer. Stationed in Paris during the war, he had little interest in espianoge--or anything that might get in the way of his comfortable existance--and frequently annoyed Sergeyev and MI5. He was captured by the Americans in Paris, having been late to escape, and was cleared of any serious crimes and released.",
  "picture" : "emileKliemann"
  },
  {
  "firstName" : "Karl-Erich",
  "lastName" : "Kuhlenthal",
  "birthDate" : "1908",
  "deathDate" : "October 25, 1975",
  "affiliation" : "Abewhr",
  "bio" : "Kuhlenthal was a high ranking Abewhr agent stationed in Madrid. He served as Juan Pujol's Abewhr case officer and was the Abewhr officer responsible for procuring the \"top secret\" documents from the briefcase of a drowned British pilot during Operation Mincemeat.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Elvira",
  "lastName" : "de la Fuente Chaudoir",
  "birthDate" : "--",
  "deathDate" : "1996",
  "affiliation" : "MI5",
  "bio" : "Alias: Bronx (MI5), Cyril (MI6), Dorette (Abewhr)\nThe daughter of a Purevian guano magnate, Chaudoir had the ability to travel, even in a world at war. She was recruited by MI6 and sent to Cannes to attract the German's attention. There, she was recruited again, this time by Abewhr agent \"Bibi\" Bleil. She became part of MI5's double cross program.",
  "picture" : "elviraDeLaFuenteChaudoir"
  },
  {
  "firstName" : "Helmut \"Bibi\"",
  "lastName" : "Bleil",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "Abewhr",
  "bio" : "Bleil met Elvira de la Fuente Chaudoir in a casino in Cannes and recruited the debt prone gambling girl to the Abewhr, unaware she already worked for MI6.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Brendt",
  "lastName" : "Schluetter",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "Abewhr",
  "bio" : "Schluetter was Elvira de la Fuente Chaudoir's Abewhr case officer.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Monique",
  "lastName" : "Deschamps",
  "birthDate" : "",
  "deathDate" : "",
  "affiliation" : "",
  "bio" : "Alias: Deschamps was an agent for the Interallie and later married Roman Czerniawski.",
  "picture" : "moniqueDeschamps"
  },
  {
  "firstName" : "Guy",
  "lastName" : "Lidell",
  "birthDate" : "November 8, 1892",
  "deathDate" : "December 3, 1958",
  "affiliation" : "MI5",
  "bio" : "Guy Lidell was the director of the B division of MI5, which contained the Double Cross program (Division B.1.a)",
  "picture" : "guyLidell"
  },
  {
  "firstName" : "John",
  "lastName" : "Moe",
  "birthDate" : "May 31, 1919",
  "deathDate" : "July 7, 2001",
  "affiliation" : "MI5",
  "bio" : "Moe, along with Tor Glad, was sent to Britain as sabotuers for the Abewhr. They were captured by the British and turned, becoming double agents.",
  "picture" : "johnMoe"
  },
  {
  "firstName" : "Tor",
  "lastName" : "Glad",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Glad, along with John Moe, was sent to Britain as sabotuers for the Abewhr. They were captured by the British and turned, becoming double agents.",
  "picture" : "torGlad"
  },
  {
  "firstName" : "Clifton",
  "lastName" : "James",
  "birthDate" : "1898",
  "deathDate" : "May 8, 1963",
  "affiliation" : "Royal Army Pay Corps",
  "bio" : "James was an unsucsessful actor, known for entertaining other soldiers with his spot on impersonation of General Montgomery. He was selected by MI5 for Operation Copperhead, in which he impersonated General Montgomery on a military inspection tour in Gibraltor, giving the impression that the invassion of Normandy was not iminent. He went on to write a book about his experiences called 'I Was Monty's Double' and starred in the film adaptation.",
  "picture" : "cliftonJames"
  },
  {
  "firstName" : "Charles",
  "lastName" : "de Salis",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI6",
  "bio" : "De Salis was an MI6 officer stationed in Lisbon and worked with Johnny Jebsen.",
  "picture" : "charlesDeSalis"
  },
  {
  "firstName" : "Hans",
  "lastName" : "Brendes",
  "birthDate" : "1922",
  "deathDate" : "April 15, 1971",
  "affiliation" : "Abewhr",
  "bio" : "Brendes, an arms dealer, made friends with Johnny Jebsen and began spying on him, eventually turning him in, which led to his kidnapping. After the war, he vanished for many years, despite strigent efforts by MI5 to locate him and bring him to justice.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Wilhelm",
  "lastName" : "Kuebart",
  "birthDate" : "March 4, 1913",
  "deathDate" : "September 24, 1993",
  "affiliation" : "Abewhr",
  "bio" : "Kuebart, referred to as \"the most intelligent man in the Abwehr\", was Georg Hansen's deputy. He was imeadietely arrested after the July 20th bomb plot, but was amazingly acquitted.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Aloys",
  "lastName" : "Schreiber",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "Abewhr",
  "bio" : "Schreiber was responsible for orchestrating the kidnapping of Johnny Jebsen. ",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Gisela",
  "lastName" : "Ashley",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "A German with a hatred for Nazism, Ashley served at MI5's German expert.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Ian",
  "lastName" : "Fleming",
  "birthDate" : "May 28, 1908",
  "deathDate" : "August 12, 1964",
  "affiliation" : "MI5",
  "bio" : "Fleming worked with MI5 during the war and used his wartime experiences to create his famous character James Bond, inspired by double agent Dusko Popov. During the war, he submitted a suggestion of planting a corpse, dressed as an officer, with fake top secret papers in order to decieve the enemy, an idea which he got from a book.",
  "picture" : "ianFleming"
  },
  {
  "firstName" : "Leo",
  "lastName" : "Marks",
  "birthDate" : "Septemeber 24, 1920",
  "deathDate" : "January 15, 2001",
  "affiliation" : "SOE",
  "bio" : "Marks was a cryptographer and head of communications for the SOE.",
  "picture" : "leoMarks"
  },
  {
  "firstName" : "John Baker",
  "lastName" : "White",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "White was a British officer who concieved of the idea of convincing the Germans that the British had a wonder weapon that could set the English Channel on fire. Surprisingly, his strategy worked and terrified the Germans.",
  "picture" : "white"
  },
  {
  "firstName" : "Richard",
  "lastName" : "Walker",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Walker, a pigeon enthusiast, was determined to find a way for birds to help the Allies win the war. Among his plans included a program to bring down enemy pigeons released in Britain with a team of trained falcons and infiltrating German pigeon lofts in France with second-rate British pigeons, throwing the reliability of the German pigeon program into doubt.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Stephan",
  "lastName" : "von Groning",
  "birthDate" : "May 7, 1898",
  "deathDate" : "1982",
  "affiliation" : "Abewhr",
  "bio" : "Von Groning was the Abwehr officer in charge of training German spy Eddie Chapman in France, prior to his first mission to Britain. After Chapman's return, he insisted on working with his old spymaster again.",
  "picture" : "stephanVonGroning"
  },
  {
  "firstName" : "Walter",
  "lastName" : "Praetorius",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "SS",
  "bio" : "Praetorius helped Stephan von Groning train spy Eddie Chapman, who he had a distaste for. This feeling was further exasperated after Chapman returned and demanded the old team be reassembled, preventing Praetorius, at the last minute, from fighting on the Eastern front. Fascinated by English country dancing, Praetorius finally escaped Chapman by convincing the German military of the benefits of dancing and being appointed to train the army in English country dancing.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Robin \"Tin Eye\"",
  "lastName" : "Stephens",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Stephens was in charge of Camp 020, where captured enemy agents were interrogated.",
  "picture" : "robinTinEyeStephens"
  },
  {
  "firstName" : "Victor",
  "lastName" : "Rothschild",
  "birthDate" : "October 31, 1910",
  "deathDate" : "March 20, 1990",
  "affiliation" : "MI5",
  "bio" : "The 3rd baron of Rothschild worked for MI5 during the war, specializing in explosives.",
  "picture" : "victorRothschild"
  },
  {
  "firstName" : "Ronnie",
  "lastName" : "Reed",
  "birthDate" : "October 18, 1916",
  "deathDate" : "January 22, 1995",
  "affiliation" : "MI5",
  "bio" : "Reed was a radio opperator and worked as Eddie Chapman's case officer. His photo was used for the identity card of the drowned pilot in Operation Mincemeat.",
  "picture" : "ronnieReed"
  },
  {
  "firstName" : "Dagmar",
  "lastName" : "Lahlum",
  "birthDate" : "1922",
  "deathDate" : "1999",
  "affiliation" : "Norwegian Resistance",
  "bio" : "Lahlum worked with the Norwegian Resistance. She met and fell in love with Eddie Chapman during his second time in occupied Europe and was glad to learn he was a double agent for the British. After the war, she was branded as compromising with the Germans due to her relationship with Chapman.",
  "picture" : "dagmarLahlum"
  },
  {
  "firstName" : "Jasper",
  "lastName" : "Maskelyne",
  "birthDate" : "1902",
  "deathDate" : "1973",
  "affiliation" : "MI5",
  "bio" : "Maskelyne was a skilled magician, responsible for the faked sabotage of the De Haviland airplane factory, supposedly destroyed by Eddie Chapman. He also is said to have previously done extensive acts of misdirection against the Afrika Corp, including using mirrors to obscure the location of the Suez Cannal, but most of that cannot be proven.",
  "picture" : "jasperMaskelyne"
  },
  {
  "firstName" : "Michael",
  "lastName" : "Ryde",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "",
  "bio" : "Ryde replaced Ronnie Reed as Eddie Chapman's case officer near the end of the war, a situation hated by both Ryde and Chapman.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Reginald",
  "lastName" : "Kearon",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "Britain",
  "bio" : "Kearon captained the ship The City of Lancaster, which returned Eddie Chapman to occupied Europe. He helped Chapman with his scheme to get ahold of an enemy bomb by pretending to sabotage The City of Lancaster. Kearon went on to captain a number of other prominent ships during the war.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Alan",
  "lastName" : "Tooth",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Tooth, along with Paul Blackwell, kept an eye on Eddie Chapman for MI5 during his time in Britain.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Paul",
  "lastName" : "Blackwell",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "MI5",
  "bio" : "Blackwell, along with Alan Tooth, kept an eye on Eddie Chapman for MI5 during his time in Britain.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Jimmy",
  "lastName" : "Hunt",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "--",
  "bio" : "Hunt was a member of Eddie Chapman's gang prior to his arrest. When Chapman was sent to Britain, he was instructed to get in touch with some of his old associates. MI5 impersonated Hunt, who was in prison unaware of how his identity was being used, as an underworld friend to help Chapman.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Mathilde",
  "lastName" : "Carre",
  "birthDate" : "June 30, 1908",
  "deathDate" : "May 30, 2007",
  "affiliation" : "Interallie",
  "bio" : "Carre worked with Roman Czerniawski to form the Interallie. However, after her arrest, she revealed the details of the organization to Hugo Bleicher.",
  "picture" : "mathildeCarre"
  },
  {
  "firstName" : "Hugo",
  "lastName" : "Bleicher",
  "birthDate" : "August 9, 1899",
  "deathDate" : "August 1982",
  "affiliation" : "Abewhr",
  "bio" : "Bleicher was the Abewhr spy hunter who took down the Interallie. He later claimed, unconvincingly, to have never been fooled by Roman Czeniawski.",
  "picture" : "hugoBleicher"
  },
  {
  "firstName" : "Alexis",
  "lastName" : "von Roenne",
  "birthDate" : "--",
  "deathDate" : "October 12, 1944",
  "affiliation" : "Abewhr",
  "bio" : "Von Roenne was an anti-Nazi Abewhr officer implicated in the July 20th bomb plot. He repeatedly overcalculated the number of Allied troops in Britain during the build up to D-Day for reasons unknown. He was executed at Plotzensee prison.",
  "picture" : "alexisVonRoenne"
  },
  {
  "firstName" : "Arthur",
  "lastName" : "Owens",
  "birthDate" : "April 14, 1899",
  "deathDate" : "December 24, 1957",
  "affiliation" : "MI5",
  "bio" : "Alias: Snow (MI5)\nOwens was the Double Cross's first double agent. While not truly a sucsess himself, he proved the potential value of double agents to MI5. He was pulled after MI5 began suspecting he might be a triple agent and was jailed for the rest of the war.",
  "picture" : "arthurOwens"
  },
  {
  "firstName" : "Franklin Delano",
  "lastName" : "Roosevelt",
  "birthDate" : "January 30, 1882",
  "deathDate" : "April 12, 1945",
  "affiliation" : "America",
  "bio" : "Roosevelt was the President of the United States from 1933 to 1945.",
  "picture" : "franklinDelanoRoosevelt"
  },
  {
  "firstName" : "Adolf",
  "lastName" : "Hitler",
  "birthDate" : "April 20, 1889",
  "deathDate" : "April 30, 1945",
  "affiliation" : "Germany",
  "bio" : "Hitler was the Fuhrer of Germany from 1933 to 1945.",
  "picture" : "adolfHitler"
  },
  {
  "firstName" : "Harry S.",
  "lastName" : "Truman",
  "birthDate" : "May 8, 1884",
  "deathDate" : "December 26, 1972",
  "affiliation" : "America",
  "bio" : "Truman was the President of the United States from 1945 to 1953.",
  "picture" : "harrySTruman"
  },
  {
  "firstName" : "Hideki",
  "lastName" : "Tojo",
  "birthDate" : "December 30, 1884",
  "deathDate" : "December 23, 1948",
  "affiliation" : "Japan",
  "bio" : "Tojo was the Prime Minister of Japan from 1941 to 1945. He was a general in the Japanese Imperial Army and ordered the attack on Pearl Harbor. After the war, he was executed for war crimes.",
  "picture" : "hidekiTojo"
  },
  {
  "firstName" : "Josef",
  "lastName" : "Stalin",
  "birthDate" : "December 18, 1878",
  "deathDate" : "March 5, 1953",
  "affiliation" : "Soviet Union",
  "bio" : "Stalin was the head of the Soviet Union from 1922 to 1952",
  "picture" : "josefStalin"
  },
  {
  "firstName" : "Benito",
  "lastName" : "Mussolini",
  "birthDate" : "July 29, 1883",
  "deathDate" : "April 28, 1945",
  "affiliation" : "Italy",
  "bio" : "Mussolini was the Prime Minister of Italy from 1922 to 1943.",
  "picture" : "benitoMussolini"
  },
  {
  "firstName" : "Winston",
  "lastName" : "Churchill",
  "birthDate" : "November 30, 1874",
  "deathDate" : "January 24, 1965",
  "affiliation" : "Britain",
  "bio" : "Churchill was Prime Minister of Britain from 1940 to 1945 and again from 1951 to 1955.",
  "picture" : "winstonChurchill"
  },
  {
  "firstName" : "Neville",
  "lastName" : "Chamberlain",
  "birthDate" : "March 18, 1869",
  "deathDate" : "November 9, 1940",
  "affiliation" : "Britain",
  "bio" : "Chamberlain was the Prime Minister at the very beginning of World War Two until May 1940.",
  "picture" : "nevilleChamberlain"
  },
  {
  "firstName" : "Dwight D.",
  "lastName" : "Eisenhower",
  "birthDate" : "October 14, 1890",
  "deathDate" : "March 28, 1969",
  "affiliation" : "America",
  "bio" : "Eisenhower was Supreme Allied Commander Europe.",
  "picture" : "dwightDEisenhower"
  },
  {
  "firstName" : "Hirohito,",
  "lastName" : "Emperor Showa",
  "birthDate" : "April 29, 1901",
  "deathDate" : "January 7, 1989",
  "affiliation" : "Japan",
  "bio" : "Emperor Showa was the Emperor of Japan from 1926 to 1989.",
  "picture" : "hirohitoEmperorShowa"
  },
  {
  "firstName" : "Yamamoto",
  "lastName" : "Isoruko",
  "birthDate" : "April 4, 1884",
  "deathDate" : "April 18, 1943",
  "affiliation" : "Japan",
  "bio" : "Yamamoto was a marshal admiral and the commander-in-chief of the combined fleet. He was responsible for Pearl Harbor. He died when his plane was shot down in 1943.",
  "picture" : "yamamotoIsoruko"
  },
  {
  "firstName" : "Erwin",
  "lastName" : "Rommel",
  "birthDate" : "November 15, 1891",
  "deathDate" : "October 14, 1944",
  "affiliation" : "Germany",
  "bio" : "Known as the Desert Fox, Rommel was one of Germany's best generals. He led the Afrika Corp in North Africa and then worked on defenses for the weak Atlantic Wall in France. After being implicated in the July 20th bomb plot, he was forced to commit suicide.",
  "picture" : "erwinRommel"
  },
  {
  "firstName" : "Bernard",
  "lastName" : "Montgomery",
  "birthDate" : "November 17, 1887",
  "deathDate" : "March 24, 1976",
  "affiliation" : "Britain",
  "bio" : "Montgomery, nicknamed \"Monty\", commanded the British Eighth Army against the Afrika Corp and during the invassion of Italy. He went on to command Allied ground forces during the invassion of Normandy.",
  "picture" : "bernardMontgomery"
  },
  {
  "firstName" : "Charles",
  "lastName" : "de Gaulle",
  "birthDate" : "November 22, 1890",
  "deathDate" : "November 9, 1970",
  "affiliation" : "France",
  "bio" : "De Gaulle was a French general and the leader of Free France.",
  "picture" : "charlesDeGaulle"
  },
  {
  "firstName" : "Douglas",
  "lastName" : "MacArthur",
  "birthDate" : "January 26, 1880",
  "deathDate" : "April 5, 1964",
  "affiliation" : "America",
  "bio" : "MacArthur was an American general and played a major war in the Pacific theater.",
  "picture" : "douglasMacarthur"
  },
  {
  "firstName" : "George S.",
  "lastName" : "Patton",
  "birthDate" : "November 11, 1885",
  "deathDate" : "December 21, 1945",
  "affiliation" : "America",
  "bio" : "Patton was an American general and led the United States Third Army in France and Germany.",
  "picture" : "georgeSPatton"
  },
  {
  "firstName" : "Adolf",
  "lastName" : "Eichmann",
  "birthDate" : "March 19, 1901",
  "deathDate" : "June 1, 1962",
  "affiliation" : "SS",
  "bio" : "Eichman was in charge of organizing the logistics of the Holocaust. He escaped capture for years in South America following the war but was eventually captured by Mossad.",
  "picture" : "adolfEichmann"
  },
  {
  "firstName" : "Joseph",
  "lastName" : "Goebbels",
  "birthDate" : "October 29, 1897",
  "deathDate" : "May 1, 1945",
  "affiliation" : "Germany",
  "bio" : "Goebbels was the Minister of Propaganda.",
  "picture" : "josephGoebbels"
  },
  {
  "firstName" : "Heinrich",
  "lastName" : "Himmler",
  "birthDate" : "October 7, 1900",
  "deathDate" : "May 1, 1945",
  "affiliation" : "SS",
  "bio" : "Himmler was the head of the Schutzstaffel (SS) and the Gestapo.",
  "picture" : "heinrichHimmler"
  },
  {
  "firstName" : "Ewen",
  "lastName" : "Montagu",
  "birthDate" : "March 19, 1901",
  "deathDate" : "July 19, 1985",
  "affiliation" : "Naval Intelligence",
  "bio" : "Montagu was a part of Naval Intelligence and was on the Double Cross committee. He was one of the architects of Operation Mincemeat and, after the war, wrote 'The Man Who Never Was', an account of the operation.",
  "picture" : "ewenMontagu"
  },
  {
  "firstName" : "Hermann",
  "lastName" : "Goring",
  "birthDate" : "January 12, 1893",
  "deathDate" : "October 15, 1946",
  "affiliation" : "Germany",
  "bio" : "Goring was an early member of the Nazi party, injured in the Beer Hall Putsch in 1923. He was the commander of the Luftwaffe and vice-chancellor of Germany.",
  "picture" : "hermannGoring"
  },
  {
  "firstName" : "Eva",
  "lastName" : "Braun",
  "birthDate" : "February 6, 1912",
  "deathDate" : "April 30, 1945",
  "affiliation" : "Germany",
  "bio" : "Braun was Hitler's girlfriend and personal photographer. The German public was not aware of her relationship with Hitler. She and Hitler committed suicide together as the Soviets took Berlin.",
  "picture" : "evaBraun"
  },
  {
  "firstName" : "Joseph",
  "lastName" : "Mengele",
  "birthDate" : "March 19, 1911",
  "deathDate" : "February 7, 1979",
  "affiliation" : "SS",
  "bio" : "Mengele was a doctor at Auschwitz concentration camp. He preformed horrific experiments of prisoners, including children. He eluded capture after the war and died in Argentina.",
  "picture" : "josephMengele"
  },
  {
  "firstName" : "Reinhard",
  "lastName" : "Heydrich",
  "birthDate" : "March 7, 1904",
  "deathDate" : "June 4, 1942",
  "affiliation" : "SS",
  "bio" : "Heydrich was the brutal deputy protector of Bohemia and Moravia and the founding head of the SD, the intelligence branch of the SS. He was assassinated by the SOE, leading to horrific reprisals.",
  "picture" : "reinhardHeydrich"
  },
  {
  "firstName" : "Rudolf",
  "lastName" : "Hess",
  "birthDate" : "November 25, 1901",
  "deathDate" : "April 16, 1947",
  "affiliation" : "SS",
  "bio" : "Hoss was the commandant of Auschwitz concentration camp.",
  "picture" : "rudolfHoss"
  },
  {
  "firstName" : "Claus",
  "lastName" : "von Stauffenberg",
  "birthDate" : "November 15, 1907",
  "deathDate" : "July 21, 1944",
  "affiliation" : "Germany",
  "bio" : "nVon Stauffenberg was a German officer who attempted to assassinate Hilter in the July 20th bomb plot. The plot failed after the briefcase containing the bomb was moved and a table absorbed some of the impact, shielding Hitler.",
  "picture" : "clausVonStauffenberg"
  },
  {
  "firstName" : "Hans",
  "lastName" : "Scholl",
  "birthDate" : "September 22, 1918",
  "deathDate" : "February 22, 1943",
  "affiliation" : "White Rose",
  "bio" : "Scholl was a member of the White Rose, a non-violent resistance movement against the Nazis. The group authored six anti-Nazi leaflets and secretly distributed them. After he and his sister Sophie Scholl were seen with the leaflets, they were tried for treason and executed.",
  "picture" : "hansScholl"
  },
  {
  "firstName" : "Sophie",
  "lastName" : "Scholl",
  "birthDate" : "May 9, 1921",
  "deathDate" : "February 22, 1943",
  "affiliation" : "White Rose",
  "bio" : "Scholl was a member of the White Rose, a non-violent resistance movement against the Nazis. The group authored six anti-Nazi leaflets and secretly distributed them. After she and her brother Hans Scholl were seen with the leaflets, they were tried for treason and executed.",
  "picture" : "sophieScholl"
  },
  {
  "firstName" : "Christoph",
  "lastName" : "Probst",
  "birthDate" : "November 6, 1918",
  "deathDate" : "February 22, 1943",
  "affiliation" : "White Rose",
  "bio" : "Probst was a member of the White Rose, a non-violent resistance movement against the Nazis. The group authored six anti-Nazi leaflets and secretly distributed them. He was arrested along with Hans and Sophie Scholl, and they were tried for treason and executed.",
  "picture" : "christophProbst"
  },
  {
  "firstName" : "Alexander",
  "lastName" : "Schmorell",
  "birthDate" : "September 16, 1917",
  "deathDate" : "July 13, 1943",
  "affiliation" : "White Rose",
  "bio" : "Schmorell as a member of the White Rose, a non-violent resistance movement against the Nazis. The group authored six anti-Nazi leaflets and secretly distributed them. He was arrested and executed.",
  "picture" : "alexanderSchmorell"
  },
  {
  "firstName" : "Willi",
  "lastName" : "Graf",
  "birthDate" : "January 2, 1918",
  "deathDate" : "October 12, 1943",
  "affiliation" : "White Rose",
  "bio" : "Graf was a member of the White Rose, a non-violent resistance movement against the Nazis. The group authored six anti-Nazi leaflets and secretly distributed them. He was arrested and executed.",
  "picture" : "williGraf"
  },
  {
  "firstName" : "Kurt",
  "lastName" : "Huber",
  "birthDate" : "October 24, 1893",
  "deathDate" : "July 13, 1943",
  "affiliation" : "White Rose",
  "bio" : "Huber, a professor, was a member of the White Rose, a non-violent resistance movement against the Nazis. The group authored six anti-Nazi leaflets and secretly distributed them. He was arrested and executed.",
  "picture" : "kurtHuber"
  },
  {
  "firstName" : "Kim",
  "lastName" : "Philby",
  "birthDate" : "January 1, 1912",
  "deathDate" : "May 11, 1988",
  "affiliation" : "Soviet Union",
  "bio" : "Philby was a double agent for the Soviet Union and a member of the Cambridge Five. During World War Two, he worked in the SOE, MI5, and MI6.",
  "picture" : "kimPhilby"
  },
  {
  "firstName" : "Donald Duart",
  "lastName" : "Maclean",
  "birthDate" : "May 25, 1913",
  "deathDate" : "March 6, 1983",
  "affiliation" : "Soviet Union",
  "bio" : "Maclean was a double agent for the Soviet Union and a member of the Cambridge Five. During World War Two, he worked in the Foreign Office and, near the end of the war, was promoted to the British Embassy in the United States.",
  "picture" : "donaldDuartMaclean"
  },
  {
  "firstName" : "Guy",
  "lastName" : "Burgess",
  "birthDate" : "April 16, 1911",
  "deathDate" : "August 30, 1963",
  "affiliation" : "Soviet Union",
  "bio" : "Burgess was a double agent for the Soviet Union and a member of the Cambridge Five. During World War Two, he worked for the Foreign Office.",
  "picture" : "guyBurgess"
  },
  {
  "firstName" : "Anthony",
  "lastName" : "Blunt",
  "birthDate" : "September 26, 1907",
  "deathDate" : "March 26, 1983",
  "affiliation" : "Soviet Union",
  "bio" : "Blunt was a double agent for the Soviet Union and a member of the Cambridge Five. During World War Two, he worked for MI5.",
  "picture" : "anthonyBlunt"
  },
  {
  "firstName" : "John",
  "lastName" : "Cairncross",
  "birthDate" : "July 25, 1913",
  "deathDate" : "October 8, 1995",
  "affiliation" : "Soviet Union",
  "bio" : "Cairncross was a double agent for the Soviet Union and is believed to be the fifth member of the Cambridge Five. During World War Two, he worked at Bletchley Park.",
  "picture" : "johnCairncross"
  },
  {
  "firstName" : "Ignacio Molina",
  "lastName" : "Perez",
  "birthDate" : "--",
  "deathDate" : "--",
  "affiliation" : "Abewhr",
  "bio" : "Alias: Cosmo (Abewhr)\nPerez was a spy for Abewhr in Gibraltar. He passed on the news of \"General Montgomery\"'s presence in Gibraltar as a result of Opperation Copperhead.",
  "picture" : "noImageAvailable"
  },
  {
  "firstName" : "Wulf",
  "lastName" : "Schmidt",
  "birthDate" : "December 7, 1911",
  "deathDate" : "October 19, 1992",
  "affiliation" : "MI5",
  "bio" : "Alias: Tate (MI5), Leonhardt (Abewhr)\nSchmidt was MI5's longest running double agent, active from 1940 to 1945.",
  "picture" : "wulfSchmidt"
  },
  {
  "firstName" : "Gosta",
  "lastName" : "Caroli",
  "birthDate" : "November 6, 1902",
  "deathDate" : "May 8, 1975",
  "affiliation" : "MI5",
  "bio" : "Alias: Summer (MI5)\nCaroli was a short-lived double agent for MI5. After he attempted to escape on a bicycle with a canoe, a can of sardines, and a pineapple, he was pulled and interned for the remainder of the war.",
  "picture" : "gostaCaroli"
  },
  {
  "firstName" : "Oskar",
  "lastName" : "Schindler",
  "birthDate" : "April 28, 1908",
  "deathDate" : "October 9, 1974",
  "affiliation" : "",
  "bio" : "Schindler was a German factory owner who saved 1,200 Jews by employing them in his factory and bribing his German connections to protect them.",
  "picture" : "oskarSchindler"
  },
  {
  "firstName" : "Raoul",
  "lastName" : "Wallenberg",
  "birthDate" : "August 4, 1912",
  "deathDate" : "January 17, 1945 (Disappeared)",
  "affiliation" : "",
  "bio" : "Wallenberg was a Swedish diplomat, who saved tens of thousands of Jews in Hungary by issuing protective passports and hiding them in buildings designated as part of the Swedish embassy. Near the end of the war, he was arrested by the Soviets and disappeared.",
  "picture" : "raoulWallenberg"
  },
  {
  "firstName" : "Giorgio",
  "lastName" : "Perlasca",
  "birthDate" : "January 31, 1910",
  "deathDate" : "August 15, 1992",
  "affiliation" : "",
  "bio" : "Perlasca posed as a Spanish consul in Hungary with the help of Angel Sanz Briz. They printed protective visa for Jews and created safe houses, declaring them territory of Spain. He continued his work after Sanz Briz and the Spanish embassy were moved to Switzerland, claiming Sanz Briz was on leave and had put him in charge in his absence. In all, he saved 5,218 Jews.",
  "picture" : "giorgioPerlasca"
  },
  {
  "firstName" : "Angel",
  "lastName" : "Sanz Briz",
  "birthDate" : "September 28, 1910",
  "deathDate" : "June 11, 1980",
  "affiliation" : "Spanish Embassy in Hungary",
  "bio" : "Sanz Briz was a Spanish diplomat to Hungary. He and Giorgio Perlasca saved 5,218 Jews.",
  "picture" : "angelSanzBriz"
  },
  {
  "firstName" : "Albert",
  "lastName" : "Goring",
  "birthDate" : "March 9, 1895",
  "deathDate" : "December 20, 1966",
  "affiliation" : "",
  "bio" : "Goring, younger brother of Hermann Goring, worked to help Jews and political dissidents escape Nazi Germany. As export director of a factory in Czechoslovakia, he used his position to request Jewish laborers from concentration camps and help them escape. He forged his brother's signature to enable arrested political dissidents to escape, had connections with the Czech resistance, and used his brother's influence to get out of trouble whenever he was stopped.",
  "picture" : "albertGoring"
  },
  {
  "firstName" : "\"Mad\" Jack",
  "lastName" : "Churchill",
  "birthDate" : "September 16, 1906",
  "deathDate" : "March 8, 1996",
  "affiliation" : "British Army",
  "bio" : "Churchill, no relation of Winston Churchill, has the only known, confirmed kill with a longbow in World War Two. He was captured after the rest of his unit was killed and sent to the infamous, escape-proof Sachesenhausen concentration camp from which he escaped.",
  "picture" : "madJackChurchill"
  },
  {
  "firstName" : "Tommy",
  "lastName" : "MacPherson",
  "birthDate" : "October 4, 1920",
  "deathDate" : "November 6, 2014",
  "affiliation" : "British Army",
  "bio" : "MacPherson was a British commando active in France. He did so much damage that the Germans placed a 300,000 franc bounty on his head. At the end of the war, he negotiated the surrender 23,000 terrified German soldiers to him and two other men, after bluffing and claiming he had access to tanks, artillery, and the RAF.",
  "picture" : "tommyMacpherson"
  },
  {
  "firstName" : "Irena",
  "lastName" : "Sendler",
  "birthDate" : "February 15, 1910",
  "deathDate" : "May 12, 2008",
  "affiliation" : "",
  "bio" : "Sendler, a social worker in Poland, smuggled approximately 2,500 Jewish children out of the Warsaw Ghetto before they could be taken to concentration camps, and hid them, hoping to reunite them with their parents after the war. However, almost all the parents died in Treblinka extermination camp. She was arrested by the Gestapo and sentenced to death, but some of the people she worked with were able to bribe the guards and she went into hiding, returning to Warsaw under a fake identity to continue helping others.",
  "picture" : "irenaSendler"
  },
  {
  "firstName" : "Corrie",
  "lastName" : "ten Boom",
  "birthDate" : "April 15, 1892",
  "deathDate" : "April 15, 1983",
  "affiliation" : "",
  "bio" : "Ten Boom, along with her family, worked to hide Jews during the Holocaust. Ten Boom, her father, and her sister Betsie were arrested by the Gestapo and sent to concentration camps. Her father and Betsie did not survive. After the war, Ten Boom wrote 'The Hiding Place' about her experiences.",
  "picture" : "corrieTenBoom"
  },
  {
  "firstName" : "Nicholas",
  "lastName" : "Winton",
  "birthDate" : "May 19, 1909",
  "deathDate" : "July 1, 2015",
  "affiliation" : "",
  "bio" : "Winton organized the Kindertransport, which rescued 669 Jewish children from Czechoslovakia and found homes for them in Britain during the war.",
  "picture" : "nicholasWinton"
  }
  ]
