//
//  Bios.swift
//  RandomNumbers2
//
//  Created by Marcy Thompson on 3/29/17.
//  Copyright © 2017 Marcella Thompson. All rights reserved.
//

import Foundation

class Bios: CustomStringConvertible {
    var firstName: String
    var lastName: String
    var birthDate: String
    var deathDate: String
    var affiliation: String
    var bio: String
    var picture: String
    
    convenience init() {
        self.init(firstName: "", lastName: "", birthDate: "", deathDate: "", affiliation: "", bio: "", picture: "")
    }
    
    init(firstName: String, lastName: String, birthDate: String, deathDate: String, affiliation: String, bio: String, picture: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.birthDate = birthDate
        self.deathDate = deathDate
        self.affiliation = affiliation
        self.bio = bio
        self.picture = picture
    }
    
    convenience init(contactDictionary: NSDictionary) {
        self.init(firstName: (contactDictionary["firstName"] ?? "") as! String, lastName: (contactDictionary["lastName"] ?? "") as! String, birthDate: (contactDictionary["birthDate"] ?? "") as! String, deathDate: (contactDictionary["deathDate"] ?? "") as! String, affiliation: (contactDictionary["affiliation"] ?? "") as! String, bio: (contactDictionary["bio"] ?? "") as! String, picture: (contactDictionary["picture"] ?? "") as! String)
    }
    
    var description: String {
        var descriptionString = ""
        
        if (birthDate != "") {
            descriptionString += "\n\(birthDate) -"
        } else {
            descriptionString += "\n-- "
        }
        
        if (deathDate != "") {
            descriptionString += " \(deathDate)"
        } else {
            descriptionString += " --"
        }
        
        if (affiliation != "") {
            descriptionString += "\nAffiliation: \(affiliation)"
        }
        
        if (bio != "") {
            descriptionString += "\n\(bio)"
        }
        
        return descriptionString
    }
    
    var fullName: String {
        return "\(firstName) \(lastName)"
    }
    
    var nameLast: String {
        return "\(lastName), \(firstName)"
    }
    
}

class TheBios: CustomStringConvertible {
    var jsonData: Data
    var jsonArray: NSArray
    var bioArray: [Bios]
    
    func sortEntries() {
        bioArray.sort{$0.nameLast.lowercased() < $1.nameLast.lowercased()}
    }
    
    var description: String {
        var bioDisplay = ""
        
        for bio in bioArray {
            bioDisplay += bio.description
            bioDisplay += "\n"
        }
        
        return bioDisplay
    }
    
    var count: Int {
        return bioArray.count
    }
    
    init() {
        jsonData = Data()
        jsonArray = []
        bioArray = []
    }
    
    func contactWithIndex(_ index: Int) -> Bios {
        return bioArray[index] ?? Bios ()
    }
    
    func loadJSONContactsWithFileName(_ fileName: String) {
        let jsonURL = Bundle.main.url(forResource: fileName, withExtension: "js")
        
        if let urlCheck = jsonURL {
            jsonData = try! Data(contentsOf: urlCheck)
        }
        
        jsonArray = try! JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSArray
        
    }
    
    func createJSONDictionary() {
        for json in jsonArray {
            let dictionary = json as! NSDictionary
            let bio = Bios(contactDictionary: dictionary)
            bioArray.append(bio)
            sortEntries()
        }
    }
}





