//
//  RandomNumbers2TableViewController.swift
//  RandomNumbers2
//
//  Created by Marcy Thompson on 9/1/16.
//  Copyright © 2016 Marcella Thompson. All rights reserved.
//

import UIKit

class BIOsTableViewController: UITableViewController {
    
    var biographies = TheBios()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        biographies.loadJSONContactsWithFileName("BioInfo")
        biographies.createJSONDictionary()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return biographies.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "bioCell", for: indexPath)
        
        let biography = biographies.contactWithIndex((indexPath as NSIndexPath).row)

        
        // Configure the cell...
        
        cell.textLabel?.text = biography.fullName

        return cell
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "showDetail" {
            let showController = segue.destination as! DetailViewController
            let selectedRow = (tableView.indexPathForSelectedRow as NSIndexPath?)?.row ?? 0
            showController.bio = biographies.contactWithIndex(selectedRow)
        }
    }
    
    

}
